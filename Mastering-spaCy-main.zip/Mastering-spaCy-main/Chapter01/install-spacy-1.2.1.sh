sudo pip3 install spacy
python3 -m spacy info
